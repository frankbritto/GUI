<?php
/* User login process, checks if user exists and password is correct */
