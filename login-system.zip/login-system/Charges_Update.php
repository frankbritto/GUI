<?php

$host="localhost"; // Host name
$username="root"; // Mysql username
$password=""; // Mysql password
$db_name="charges"; // Database name
$tbl_name="tata"; // Table name


// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

if(isset($_POST['Submit']))
{
// Get values from form
$Wheeling=$_POST['Wheeling'];
$Energy=$_POST['Energy'];
$Regulatory=$_POST['Regulatory'];
$Fixed=$_POST['Fixed'];
// Update table 
$sql = 'UPDATE tata SET Wheeling='.$Wheeling.', Energy='.$Energy.', Regulatory='.$Regulatory.', Fixed='.$Fixed.' WHERE id="1"';
//echo $sql;
$result=mysql_query($sql);
header("location: try.php");
// if successfully insert data into database, displays message "Successful".
/*if($result){
echo "Successful";
echo "<BR>";
//<a href='index1.html'></a>";//
}

else {
echo "ERROR";
}*/
}
?>

<?php
// close connection
mysql_close();
?>
