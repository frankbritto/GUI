<!DOCTYPE HTML>
<!--
	Fractal by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Welcome Page</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>

	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.dropdown-submenu {
    position: relative;
}

.dropdown-submenu .dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -1px;
}
</style>
</head>
<body>
	<body id="top">

		<!-- Header -->
			<header id="header">
				<div class="content">
					<h1><a href="#">Welcome Admin</a></h1>
					
					<ul class="actions">
					    <li><a href="#one" class="button icon fa-chevron-down scrolly">Create User</a></li>
						<li><a href="#two" class="button icon fa-chevron-down scrolly">View User details</a></li>
						<li><a href="#three" class="button icon fa-chevron-down scrolly">Change rates</a></li>
					</ul>
				</div>
			</header>

		<!-- One -->
	<section id="one" class="wrapper style2 special">
		<header class="major">		
			<div class="form">
			<div class="col-lg-13">
    <h2>Enter User Details</h2>
	<form action="display_table.php" onsubmit="return validate()" method="get">
	</form>
	<form action="finalinsert.php" onsubmit="return validate()" method="post">
	<p><b><u>SIGN UP</u></b></p>
	<div style="width:500px; margin:0 auto;">
	<label>Firstname:</label>
	<input type="text" placeholder="Enter your firstname" id="fn" name="firstname" required>
	</div>
	<div style="width:500px; margin:0 auto;">
	<label>Lastname:</label>
	<input type="text" placeholder="Enter your lastname" id="ln" name="lastname" required>
	</div>
	<div style="width:500px; margin:0 auto;">
	<label>Email:</label>
	<input type="text" placeholder="Enter your email-id" id="em" name="email" required>
	</div>
	<div style="width:500px;margin:0 auto;">
	<label>Contact Number:</label>
	<input type="text" placeholder="Enter your contact no" id="cn" name="contactno" required>
	</div>
	<div style="width:500px; margin:0 auto;">
	<label>Id:</label>
	<input type="text" placeholder="Enter your Id" id="ide" name="id" required><br>
	</div>
	<input type="submit" value="Submit">
	</form>
  </div>
  </section>

<?php

mysql_connect('localhost','root','');
mysql_select_db('accounts');
$sql="SELECT * FROM newuser";
$records=mysql_query($sql);



?>
<!--<html>
<head>
<title>data</title>
</head>
<body>
<table width="600" border="1" cellpadding="1" cellspacing="1">
<tr>
<th>first_name</th>
<th>last_name</th>
<th>email</th>
<th>contactno</th>
<th>id</th>
<tr>
-->

<title>data</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	

	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.dropdown-submenu {
    position: relative;
}

.dropdown-submenu .dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -1px;
}
</style>
</head>
<section id="two" class="wrapper style2 special">
<div class="row" style="width:500px; margin:0 auto;">
                <div class="col-lg-13">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Users details will be displayed as follows
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table align="center" class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
											<th>Contact No.</th>
											<th>ID</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
while($newuser=mysql_fetch_assoc($records)){

echo "<tr>";
echo "<td>".$newuser['first_name']."</td>";
echo "<td>".$newuser['last_name']."</td>";
echo "<td>".$newuser['email']."</td>";
echo "<td>".$newuser['contactno']."</td>";
echo "<td>".$newuser['id']."</td>";


echo "</tr>";

}



?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
				
            </div>
  
</section>  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

<section id="three" class="wrapper">
<div class="container">
  <div class="dropdown">
<div class="row" style="width:500px; margin:0 auto;">
                <div class="col-lg-12">
			<form action="Charges_Update.php" method="post">
                    <div class="panel panel-default">
                        <div class="panel-heading">
						
                            Change Additional Charges
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div style="width:200px; margin:0 auto;">
                                        <div class="form-group">
										<div style="width:500px; margin:0 auto;">
                                            <label>Tata</label>
											<div style="width:200px; margin:0 auto;">
                                            <input class="form-control" name="Wheeling">
											<div style="width:200px; margin:0 auto;">
                                            <p class="help-block">Wheeling</p>
										</div>
									
								</div>
                            </div>
							
							<div class="row">
                                <div class="col-lg-3">
                                    <div style="width:200px; margin:0 auto;">
                                        <div class="form-group">
										<div style="width:500px; margin:0 auto;">
										<div style="width:200px; margin:0 auto;">
                                            <input class="form-control" name="Energy">
											<div style="width:200px; margin:0 auto;">
                                            <p class="help-block">Energy</p>
										</div>
									
								</div>
                            </div>
							
							<div class="row">
                                <div class="col-lg-3">
                                   <div style="width:200px; margin:0 auto;"> 
                                        <div class="form-group">
										<div style="width:500px; margin:0 auto;">
										<div style="width:200px; margin:0 auto;">
                                            <input class="form-control" name="Regulatory">
											<div style="width:200px; margin:0 auto;">
                                            <p class="help-block">Regulatory</p>
										</div>
								</div>
                            </div>
							
							<div class="row">
                                <div class="col-lg-3">
                                    <div style="width:200px; margin:0 auto;">
                                        <div class="form-group">
										<div style="width:500px; margin:0 auto;">
										<div style="width:200px; margin:0 auto;">
                                            <input class="form-control" name="Fixed">
											<div style="width:200px; margin:0 auto;">
                                            <p class="help-block">Fixed/Demand</p>
										</div>
										<div style="width:500px; margin:0 auto;">
										<input type="submit" value="Submit" name="Submit">
								</div>
                            </div>
                        </div>
					</div>
				</div>
			</form>
		</div>
</div>
</div>
</section>
<!--
<p id="demo"></p>
<script>
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
function Warn() {
               //var person = prompt("Please enter your changes", "Charges to be entered");
			   var person = prompt("Please enter Charges");
			if (person=="") {
			alert("Enter valid Input");
    }
	else
	{
	alert("Change are made");
	}

}
</script>
	-->		
			

		<!-- Footer -->
			<footer id="footer">
				<ul class="icons">
					<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
					<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
				</ul>
				<p class="copyright">&copy; Untitled. Credits: <a href="http://html5up.net">HTML5 UP</a></p>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>