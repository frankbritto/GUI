<?php

$host="localhost"; // Host name
$username="root"; // Mysql username
$password=""; // Mysql password
$db_name="accounts"; // Database name
$tbl_name="newuser"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form
$first_name=$_POST['firstname'];
$last_name=$_POST['lastname'];
$email=$_POST['email'];
$contactno=$_POST['contactno'];
$ide=$_POST['id'];

// Insert data into mysql
$sql="INSERT INTO newuser(first_name, last_name, email, contactno, id)VALUES('$first_name', '$last_name', '$email', '$contactno', '$ide')";
$result=mysql_query($sql);
header("location: try.php");
// if successfully insert data into database, displays message "Successful".
/*if($result){
echo "Successful";
echo "<BR>";
//<a href='index1.html'></a>";//
}

else {
echo "ERROR";
}*/
?>

<?php
// close connection
mysql_close();
?>
