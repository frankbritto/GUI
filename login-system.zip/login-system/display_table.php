<?php

mysql_connect('localhost','root','');
mysql_select_db('accounts');
$sql="SELECT * FROM newuser";
$records=mysql_query($sql);



?>
<!--<html>
<head>
<title>data</title>
</head>
<body>
<table width="600" border="1" cellpadding="1" cellspacing="1">
<tr>
<th>first_name</th>
<th>last_name</th>
<th>email</th>
<th>contactno</th>
<th>id</th>
<tr>
-->
<!DOCTYPE HTML>
<html>
<head>
<title>data</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>

	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.dropdown-submenu {
    position: relative;
}

.dropdown-submenu .dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -1px;
}
</style>
</head>
<body>
<div class="row" style="width:400px; margin:0 auto;">
                <div class="col-lg-13">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Users details will be displayed as follows
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table align="center" class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
											<th>Contact No.</th>
											<th>ID</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
while($newuser=mysql_fetch_assoc($records)){

echo "<tr>";
echo "<td>".$newuser['first_name']."</td>";
echo "<td>".$newuser['last_name']."</td>";
echo "<td>".$newuser['email']."</td>";
echo "<td>".$newuser['contactno']."</td>";
echo "<td>".$newuser['id']."</td>";


echo "</tr>";

}



?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
				
            </div>

</body>
</html>
