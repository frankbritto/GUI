<?php 
//index.php
$connect = mysqli_connect("localhost", "root", "", "data");
$query = "SELECT * FROM Sensor1 WHERE ID='1'";
$result = mysqli_query($connect, $query);
$chart_data = '';
while($row = mysqli_fetch_array($result))
{
 $chart_data .= "{ Time:'".$row["Time"]."', Ampere:'".$row["Ampere"]."'}, ";
}
$chart_data = substr($chart_data, 0, -2);
echo $chart_data;
$query = "SELECT * FROM Sensor1 WHERE ID='2'";
$result = mysqli_query($connect, $query);
$chart_data1 = '';
while($row = mysqli_fetch_array($result))
{
 $chart_data1 .= "{Ampere1:'".$row["Ampere"]."'}, ";
}
$chart_data1 = substr($chart_data1, 0, -2);
echo $chart_data1;

?>